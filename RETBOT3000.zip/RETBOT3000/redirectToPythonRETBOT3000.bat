@echo off
cd "C:\Users\yarom\OneDrive\Desktop\RETBOT3000"
py RETBOT3000.py