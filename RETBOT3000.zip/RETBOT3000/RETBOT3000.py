"""
Reticle Overlay App
===================
Requirements: pip install pillow keyboard
Run: py RETBOT3000.py

Hotkeys (global):
  \    - Toggle reticle ON/OFF
  [    - Switch to Reticle 1
  ]    - Switch to Reticle 2
"""

import tkinter as tk
from tkinter import filedialog, messagebox
import os
import sys

try:
    from PIL import Image, ImageTk
except ImportError:
    messagebox.showerror("Missing dependency", "Pillow is not installed.\nRun: pip install pillow")
    sys.exit(1)

try:
    import keyboard
except ImportError:
    messagebox.showerror("Missing dependency", "keyboard is not installed.\nRun: pip install keyboard")
    sys.exit(1)


# ─────────────────────────────────────────────
#  OVERLAY WINDOW
# ─────────────────────────────────────────────
class OverlayWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.attributes("-transparentcolor", "#010101")
        self.config(bg="#010101")
        self.withdraw()

        self.label = tk.Label(self, bg="#010101", bd=0, highlightthickness=0)
        self.label.pack()

        self._image_ref = None

    def set_image(self, pil_image):
        if pil_image is None:
            self.label.config(image="")
            self._image_ref = None
            return
        tk_img = ImageTk.PhotoImage(pil_image)
        self._image_ref = tk_img
        self.label.config(image=tk_img)
        w, h = pil_image.size
        self.geometry(f"{w}x{h}")

    def move_to(self, x, y):
        self.geometry(f"+{x}+{y}")

    def show(self):
        self.deiconify()
        self.lift()

    def hide(self):
        self.withdraw()


# ─────────────────────────────────────────────
#  CONTROL PANEL
# ─────────────────────────────────────────────
class ControlPanel(tk.Tk):
    HOTKEY_TOGGLE = "\\"
    HOTKEY_SLOT1 = "["
    HOTKEY_SLOT2 = "]"

    def __init__(self):
        super().__init__()
        self.title("RETBOT3000")
        self.resizable(False, False)
        self.configure(bg="#0e0e12")

        self.reticles = [None, None]
        self.raw_images = [None, None]
        self.paths = ["", ""]
        self.active_slot = 0
        self.visible = False

        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.offset_x = tk.IntVar(value=0)
        self.offset_y = tk.IntVar(value=0)
        self.scale_pct = tk.IntVar(value=100)
        self._screen_cx = sw // 2
        self._screen_cy = sh // 2

        self.overlay = OverlayWindow(self)

        self._build_ui()
        self._register_hotkeys()

        self.geometry(f"+{sw - 340}+40")
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        PAD = 14
        BG = "#0e0e12"
        CARD = "#16161e"
        ACC = "#00e5ff"
        DIM = "#4a4a5a"
        FG = "#e8e8f0"
        FONT_H = ("Consolas", 11, "bold")
        FONT = ("Consolas", 10)
        FONT_S = ("Consolas", 9)

        def section(parent, title):
            frame = tk.Frame(parent, bg=CARD, bd=0, highlightthickness=1,
                             highlightbackground=DIM)
            frame.pack(fill="x", padx=PAD, pady=(0, 10))
            tk.Frame(frame, bg=DIM, height=1).pack(fill="x")
            tk.Label(frame, text=title, bg=CARD, fg=ACC,
                     font=FONT_H, anchor="w", padx=10, pady=6).pack(fill="x")
            return frame

        def labeled_entry(parent, label, var, width=6):
            row = tk.Frame(parent, bg=CARD)
            row.pack(fill="x", padx=10, pady=3)
            tk.Label(row, text=label, bg=CARD, fg=FG, font=FONT,
                     width=10, anchor="w").pack(side="left")
            e = tk.Entry(row, textvariable=var, width=width,
                         bg="#1e1e28", fg=ACC, insertbackground=ACC,
                         font=FONT, bd=0, highlightthickness=1,
                         highlightbackground=DIM, highlightcolor=ACC,
                         justify="center")
            e.pack(side="left", padx=4)
            e.bind("<Return>", lambda _: self._apply())
            e.bind("<FocusOut>", lambda _: self._apply())
            return e

        # Header
        hdr_frame = tk.Frame(self, bg="#07070b")
        hdr_frame.pack(fill="x")
        tk.Label(hdr_frame, text="◎  RETBOT3000",
                 bg="#07070b", fg=ACC, font=("Consolas", 13, "bold"),
                 padx=PAD, pady=12).pack(side="left")

        self.status_var = tk.StringVar(value="● OFF")
        self.status_lbl = tk.Label(hdr_frame, textvariable=self.status_var,
                                   bg="#07070b", fg="#ff4466",
                                   font=FONT_H, padx=PAD)
        self.status_lbl.pack(side="right")

        tk.Frame(self, bg=BG, height=10).pack()

        # Reticle slots
        slots_sec = section(self, "  RETICLE SLOTS")
        for i in range(2):
            slot_row = tk.Frame(slots_sec, bg=CARD)
            slot_row.pack(fill="x", padx=10, pady=4)

            key_label = "[" if i == 0 else "]"
            indicator = tk.Label(slot_row, text=f"{key_label}  Slot {i+1}",
                                 bg=CARD, fg=DIM, font=FONT, width=12, anchor="w")
            indicator.pack(side="left")
            setattr(self, f"_slot_lbl_{i}", indicator)

            path_var = tk.StringVar(value="No image")
            tk.Label(slot_row, textvariable=path_var, bg=CARD, fg=FG,
                     font=FONT_S, anchor="w", width=18).pack(side="left", padx=6)
            setattr(self, f"_path_var_{i}", path_var)

            btn = tk.Button(slot_row, text="Browse",
                            bg=DIM, fg=FG, font=FONT_S,
                            activebackground=ACC, activeforeground="#000",
                            bd=0, padx=8, pady=3, cursor="hand2",
                            command=lambda idx=i: self._browse(idx))
            btn.pack(side="right")

        # Position & Scale
        tfm_sec = section(self, "  POSITION & SCALE")
        labeled_entry(tfm_sec, "Offset X (px)", self.offset_x)
        labeled_entry(tfm_sec, "Offset Y (px)", self.offset_y)
        labeled_entry(tfm_sec, "Scale (%)", self.scale_pct)

        tk.Button(tfm_sec, text="Apply  ↵",
                  bg=ACC, fg="#000", font=FONT_H,
                  bd=0, padx=14, pady=6, cursor="hand2",
                  activebackground="#00b8cc",
                  command=self._apply).pack(padx=10, pady=(6, 12))

        # Hotkeys reference
        hk_sec = section(self, "  HOTKEYS")
        for key, desc in [("\\", "Toggle ON/OFF"), ("[", "Slot 1"), ("]", "Slot 2")]:
            row = tk.Frame(hk_sec, bg=CARD)
            row.pack(fill="x", padx=10, pady=2)
            tk.Label(row, text=key, bg="#1a1a24", fg=ACC,
                     font=FONT_H, width=5, pady=2).pack(side="left")
            tk.Label(row, text=desc, bg=CARD, fg=FG,
                     font=FONT_S, padx=8).pack(side="left")
        tk.Frame(hk_sec, bg=CARD, height=8).pack()

        # Toggle button
        self.toggle_btn = tk.Button(self, text="[  \\  ]  TOGGLE RETICLE",
                                    bg="#1a1a24", fg=ACC,
                                    font=("Consolas", 11, "bold"),
                                    bd=0, pady=12, cursor="hand2",
                                    activebackground=ACC, activeforeground="#000",
                                    command=self._toggle_visibility)
        self.toggle_btn.pack(fill="x", padx=PAD, pady=(0, PAD))

        self._update_slot_indicators()

    def _register_hotkeys(self):
        keyboard.add_hotkey(self.HOTKEY_TOGGLE, self._hotkey_toggle, suppress=False)
        keyboard.add_hotkey(self.HOTKEY_SLOT1, self._hotkey_slot1, suppress=False)
        keyboard.add_hotkey(self.HOTKEY_SLOT2, self._hotkey_slot2, suppress=False)

    def _hotkey_toggle(self):
        self.after(0, self._toggle_visibility)

    def _hotkey_slot1(self):
        self.after(0, lambda: self._switch_slot(0))

    def _hotkey_slot2(self):
        self.after(0, lambda: self._switch_slot(1))

    def _browse(self, idx):
        path = filedialog.askopenfilename(
            title=f"Select PNG for Slot {idx+1}",
            filetypes=[("PNG Images", "*.png"), ("All Files", "*.*")]
        )
        if not path:
            return
        try:
            img = Image.open(path).convert("RGBA")
            self.raw_images[idx] = img
            self.paths[idx] = path
            fname = os.path.basename(path)
            getattr(self, f"_path_var_{idx}").set(fname[:18])
            self._switch_slot(idx)
        except Exception as e:
            messagebox.showerror("Error", f"Could not load image:\n{e}")

    def _switch_slot(self, idx):
        self.active_slot = idx
        self._update_slot_indicators()
        self._apply()

    def _update_slot_indicators(self):
        ACC = "#00e5ff"
        DIM = "#4a4a5a"
        for i in range(2):
            lbl = getattr(self, f"_slot_lbl_{i}")
            lbl.config(fg=ACC if i == self.active_slot else DIM)

    def _apply(self):
        idx = self.active_slot
        raw = self.raw_images[idx]
        if raw is None:
            if self.visible:
                self.overlay.hide()
            return

        try:
            scale = max(1, self.scale_pct.get()) / 100.0
            ox = self.offset_x.get()
            oy = self.offset_y.get()
        except tk.TclError:
            return

        w = max(1, int(raw.width * scale))
        h = max(1, int(raw.height * scale))
        scaled = raw.resize((w, h), Image.LANCZOS)

        self.overlay.set_image(scaled)

        x = self._screen_cx + ox - w // 2
        y = self._screen_cy + oy - h // 2
        self.overlay.move_to(x, y)

        if self.visible:
            self.overlay.show()

    def _toggle_visibility(self):
        self.visible = not self.visible
        if self.visible:
            self._apply()
            self.overlay.show()
            self.status_var.set("● ON")
            self.status_lbl.config(fg="#00e5ff")
        else:
            self.overlay.hide()
            self.status_var.set("● OFF")
            self.status_lbl.config(fg="#ff4466")

    def _on_close(self):
        keyboard.unhook_all_hotkeys()
        self.overlay.destroy()
        self.destroy()


# ─────────────────────────────────────────────
if __name__ == "__main__":
    app = ControlPanel()
    app.mainloop()